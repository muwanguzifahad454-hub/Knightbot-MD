const { Client, LocalAuth } = require('whatsapp-web.js');
const qrcode = require('qrcode-terminal');

// Initialize the WhatsApp Client with specific automated cloud parameters
const client = new Client({
    authStrategy: new LocalAuth(),
    puppeteer: {
        headless: true,
        args: [
            '--no-sandbox',
            '--disable-setuid-sandbox',
            '--disable-dev-shm-usage',
            '--disable-accelerated-2d-canvas',
            '--no-first-run',
            '--no-zygote',
            '--single-process',
            '--disable-gpu'
        ]
    }
});

// Display QR code for connection inside your server logs
client.on('qr', (qr) => {
    qrcode.generate(qr, { small: true });
    console.log('--- QR CODE GENERATED ---');
    console.log('Scan the blocky QR code above to link your phone permanently!');
});

// Confirm connection status
client.on('ready', () => {
    console.log('Your WhatsApp Bot is successfully connected and running 24/7 in the cloud!');
});

// Message listening router
client.on('message', async (msg) => {
    const chat = await msg.getChat();
    const messageText = msg.body.trim();

    // 1. Core Verification Command
    if (messageText.toLowerCase() === '!ping') {
        await msg.reply('pong! 🏓');
        return;
    }

    // 2. Automated Sticker Creator Command
    if (messageText.toLowerCase() === '!sticker' && msg.hasMedia) {
        try {
            await msg.reply('⏳ Creating your sticker... hold on a second.');
            const media = await msg.downloadMedia();
            if (media) {
                await chat.sendMessage(media, {
                    sendMediaAsSticker: true,
                    stickerName: "AI Bot Master",
                    stickerAuthor: "Fahad"
                });
            } else {
                await msg.reply('❌ Could not download the image. Try again!');
            }
        } catch (err) {
            console.error(err);
            await msg.reply('❌ Error generating sticker.');
        }
        return;
    }

    // 3. Intelligent AI Text Response Command
    if (messageText.toLowerCase().startsWith('!ai ')) {
        const userPrompt = messageText.slice(4).trim();
        
        if (!userPrompt) {
            await msg.reply('🤖 Please provide a question or prompt after the command! Example: *!ai why is the sky blue?*');
            return;
        }

        try {
            await msg.reply('🤖 _Thinking..._');

            // Fetch a smart response from a public open text engine
            const response = await fetch(`https://colb.co{encodeURIComponent(userPrompt)}`);
            const data = await response.json();

            if (data && data.reply) {
                await msg.reply(`🤖 *AI Assistant:* \n\n${data.reply}`);
            } else if (data && data.choices && data.choices.text) {
                await msg.reply(`🤖 *AI Assistant:* \n\n${data.choices.text.trim()}`);
            } else {
                await msg.reply('🤖 Sorry, my AI brain is a bit foggy right now. Try rephrasing your question!');
            }
        } catch (error) {
            console.error(error);
            await msg.reply('❌ Failed to reach the AI engine. Please try again in a moment.');
        }
    }
});

client.initialize();